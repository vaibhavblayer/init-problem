
problem_preamble = r"""\documentclass{article}
\usepackage{v-problem}
\begin{document}
\end{document}"""


def problem_head(n):
    return f'{chapter}-{n}'



#def problem_title(n):
#    return f'{title}'


